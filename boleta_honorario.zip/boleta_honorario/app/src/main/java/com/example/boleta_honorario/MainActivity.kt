package com.example.boleta_honorario
import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import java.text.DecimalFormat

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val editTextMonto = findViewById<EditText>(R.id.editTextMonto)
        val radioButtonBruto = findViewById<RadioButton>(R.id.radioButtonBruto)
        val radioButtonLiquido = findViewById<RadioButton>(R.id.radioButtonLiquido)
        val buttonCalcular = findViewById<Button>(R.id.buttonCalcular)
        val buttonReiniciar = findViewById<Button>(R.id.buttonReiniciar)
        val textViewBoletaBruto = findViewById<TextView>(R.id.textViewBoletaBruto)
        val textViewHacerBoletaBruto = findViewById<TextView>(R.id.textViewHacerBoletaBruto)
        val textViewRetencionBruto = findViewById<TextView>(R.id.textViewRetencionBruto)
        val textViewRecibirPagoBruto = findViewById<TextView>(R.id.textViewRecibirPagoBruto)
        val textViewBoletaLiquido = findViewById<TextView>(R.id.textViewBoletaLiquido)
        val textViewHacerBoletaLiquido = findViewById<TextView>(R.id.textViewHacerBoletaLiquido)
        val textViewRetencionLiquido = findViewById<TextView>(R.id.textViewRetencionLiquido)
        val textViewRecibirPagoLiquido = findViewById<TextView>(R.id.textViewRecibirPagoLiquido)

        buttonCalcular.setOnClickListener {
            val montoIngresado = editTextMonto.text.toString().toDoubleOrNull() ?: 0.0
            val formatter = DecimalFormat("#,###.00")

            if (radioButtonBruto.isChecked) {
                // Cálculos para Monto Bruto
                val retencion = montoIngresado * 0.13
                val recibirPago = montoIngresado - retencion

                textViewBoletaBruto.visibility = View.VISIBLE
                textViewHacerBoletaBruto.text = "Debes hacer la boleta por: ${formatter.format(montoIngresado)}"
                textViewRetencionBruto.text = "Retención: ${formatter.format(retencion)}"
                textViewRecibirPagoBruto.text = "Recibirás un pago de: ${formatter.format(recibirPago)}"

                // Mostrar valores de Monto Líquido
                textViewBoletaLiquido.visibility = View.VISIBLE
                val hacerBoleta = montoIngresado / 0.87
                val retencionLiquido = hacerBoleta - montoIngresado
                textViewHacerBoletaLiquido.text = "Hacer boleta por: ${formatter.format(hacerBoleta)}"
                textViewRetencionLiquido.text = "Retención: ${formatter.format(retencionLiquido)}"
                textViewRecibirPagoLiquido.text = "Recibirás un pago de: ${formatter.format(montoIngresado)}"
            } else if (radioButtonLiquido.isChecked) {
                // Cálculos para Monto Líquido
                val hacerBoleta = montoIngresado / 0.87
                val retencion = hacerBoleta - montoIngresado

                textViewBoletaLiquido.visibility = View.VISIBLE
                textViewHacerBoletaLiquido.text = "Hacer boleta por: ${formatter.format(hacerBoleta)}"
                textViewRetencionLiquido.text = "Retención: ${formatter.format(retencion)}"
                textViewRecibirPagoLiquido.text = "Recibirás un pago de: ${formatter.format(montoIngresado)}"

                // Mostrar valores de Monto Bruto
                textViewBoletaBruto.visibility = View.VISIBLE
                val retencionBruto = montoIngresado * 0.13
                val recibirPagoBruto = montoIngresado - retencionBruto
                textViewHacerBoletaBruto.text = "Debes hacer la boleta por: ${formatter.format(montoIngresado)}"
                textViewRetencionBruto.text = "Retención: ${formatter.format(retencionBruto)}"
                textViewRecibirPagoBruto.text = "Recibirás un pago de: ${formatter.format(recibirPagoBruto)}"
            }
        }

        buttonReiniciar.setOnClickListener {
            // Limpiar los campos de entrada y resultados
            editTextMonto.text.clear()
            radioButtonBruto.isChecked = false
            radioButtonLiquido.isChecked = false

            // Ocultar todos los TextView de resultados
            textViewBoletaBruto.visibility = View.GONE
            textViewHacerBoletaBruto.text = ""
            textViewRetencionBruto.text = ""
            textViewRecibirPagoBruto.text = ""

            textViewBoletaLiquido.visibility = View.GONE
            textViewHacerBoletaLiquido.text = ""
            textViewRetencionLiquido.text = ""
            textViewRecibirPagoLiquido.text = ""
        }
    }
}
